/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package no4msim;

import java.sql.*;
import java.util.Scanner;

public class NO4MSIM {
    private static final String DB_URL = "jdbc:mysql://localhost/mahasiswa";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT VERSION()")) {

            if (resultSet.next()) {
                System.out.println("Database connected successfully");
                System.out.println("MySQL Version: " + resultSet.getString(1));
            }

            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                displayMenu();
                choice = getUserChoice(scanner);

                switch (choice) {
                    case 1:
                        inputData(scanner);
                        break;
                    case 2:
                        tampilData(connection);
                        break;
                    case 3:
                        updateData(scanner, connection);
                        break;
                    case 0:
                        System.out.println("Keluar dari menu.");
                        break;
                    default:
                        System.out.println("Pilihan tidak valid.");
                }
            } while (choice != 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void displayMenu() {
        System.out.println("========== Menu Utama ==========");
        System.out.println("1. Input Data");
        System.out.println("2. Tampil Data");
        System.out.println("3. Update Data");
        System.out.println("0. Keluar");
        System.out.print("Pilihan > ");
    }

    static int getUserChoice(Scanner scanner) {
        int choice = -1;
        boolean validInput = false;

        while (!validInput) {
            try {
                choice = scanner.nextInt();
                validInput = true;
            } catch (Exception e) {
                System.out.println("Masukkan angka yang valid.");
                scanner.next(); // Membersihkan buffer scanner
            }
        }
        return choice;
    }

    static void inputData(Scanner scanner) {
        System.out.println("========== Input Data Mahasiswa ==========");
        System.out.print("Masukkan Nama: ");
        String nama = scanner.nextLine();

        // Membersihkan karakter baru
        scanner.nextLine();

        System.out.print("Masukkan Alamat: ");
        String alamat = scanner.nextLine();

        // Debugging untuk memastikan nilai yang dimasukkan ke database
        System.out.println("Nama yang akan disimpan: " + nama);
        System.out.println("Alamat yang akan disimpan: " + alamat);

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO mahasiswa (nama, alamat) VALUES (?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, nama);
                preparedStatement.setString(2, alamat);

                preparedStatement.executeUpdate();

                System.out.println("Data berhasil dimasukkan ke dalam tabel mahasiswa.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void tampilData(Connection connection) {
        try {
            String query = "SELECT * FROM mahasiswa";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                System.out.println("========== Data Mahasiswa ==========");
                System.out.printf("%-5s %-20s %-20s%n", "ID", "Nama", "Alamat");

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String nama = resultSet.getString("nama");
                    String alamat = resultSet.getString("alamat");

                    System.out.printf("%-5d %-20s %-20s%n", id, nama, alamat);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    static void updateData(Scanner scanner, Connection connection) {
        System.out.println("========== Update Data Mahasiswa ==========");
        System.out.print("Masukkan ID yang akan di-update: ");
        int idToUpdate = scanner.nextInt();
        scanner.nextLine(); // Membersihkan karakter baru

        System.out.print("Masukkan Nama Baru: ");
        String newNama = scanner.nextLine();

        System.out.print("Masukkan Alamat Baru: ");
        String newAlamat = scanner.nextLine();

        try {
            String query = "UPDATE mahasiswa SET nama = ?, alamat = ? WHERE id = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, newNama);
                preparedStatement.setString(2, newAlamat);
                preparedStatement.setInt(3, idToUpdate);

                int rowsUpdated = preparedStatement.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("Data berhasil di-update.");
                } else {
                    System.out.println("ID tidak ditemukan. Data tidak di-update.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
